﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComplexInterfacesInteraction
{
    class ComplexInterfacesInteraction
    {
        static void Main(string[] args)
        {

            // loads output files from the complex interfaces program
            // checks which interface interacts with which interface
            // ouputs the results

        }
    }
}
