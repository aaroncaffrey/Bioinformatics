﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Bio;
using Bio.Extensions;
using ProteinBioinformaticsSharedLibrary;

namespace FindInteractionPartners
{
    public class FindInteractionPartners
    {
        private static void Main(string[] args)
        {
            // this program will load the homolog list in csv format and for homologs of X sequence distance return a list of all partners
            // however, some partners may be duplicates, which cannot initially be removed, since they may bind differently in other instances
            // then, because of such cases, unique id to describe each protein must be created... this is slightly problematic because
            // close target homologs of proteins are also considered to be the same protein as the query protein
            // which means that they could exist for more than one query protein


            var homolog_csv_folder = args[0];
            var sequence_file = args[1];
            var min_similarity_str = args[2];
            var min_similarity = decimal.Parse(min_similarity_str);

            var seq_list = FindAtomicContacts.LoadSequenceFile(sequence_file, new[] {null, "", "protein"}, false);


            var homolog_csv_files = Directory.GetFiles(homolog_csv_folder, "homologs_?????.csv");

            var parsed_data = new List<homolog_csv>();
            var parsed_data_lock = new object();

            var wd1 = new WorkDivision(homolog_csv_files.Length);

            for (var thread = 0; thread < wd1.ThreadCount; thread++)
            {
                var lti = thread;
                var task = Task.Run(() =>
                {
                    for (var index1 = wd1.ThreadFirstIndex[lti]; index1 <= wd1.ThreadLastIndex[lti]; index1++)
                    {
                        var file = homolog_csv_files[index1];
                        var data = File.ReadAllLines(file); //.ToList();
                        //data.RemoveRange(0, 2);

                        for (var index = 0; index < data.Length; index++)
                        {
                            if (index < 2) continue;
                            var line = data[index];
                            if (string.IsNullOrWhiteSpace(line)) continue;
                            if (line[0] == ';') continue;

                            var line_data = new homolog_csv(line);
                            lock (parsed_data_lock) parsed_data.Add(line_data);
                        }
                    }
                });
                wd1.TaskList.Add(task);
            }

            wd1.WaitAllTasks();

            Array.Clear(homolog_csv_files, 0, homolog_csv_files.Length);

            //var query_pdb_list = parsed_data.Select(a => new Tuple<string, string>(a.query_pdb_id, a.query_chainid)).ToList();

            //var target_pdb_list = parsed_data.Select(a => new Tuple<string, string>(a.target_pdb_id, a.target_chainid)).ToList();


            //var query_alignments = new List<homolog_csv>();

            var homologs_clustered = new List<List<Tuple<string, string>>>();

            //var min_similarity = 0.9m;

            foreach (var rec in parsed_data)
            {
                if (rec.alignment_score >= min_similarity)
                {
                    //var query_group = homologs_clustered.FirstOrDefault(a => a.FirstOrDefault(b => b.Item1 == rec.query_pdb_id && b.Item2 == rec.query_chainid) != null);
                    //var target_group = homologs_clustered.FirstOrDefault(a => a.FirstOrDefault(b => b.Item1 == rec.target_pdb_id && b.Item2 == rec.target_chainid) != null);

                    List<Tuple<string, string>> query_group = null;
                    List<Tuple<string, string>> target_group = null;

                    foreach (var cluster in homologs_clustered)
                    {
                        var xq = cluster.FirstOrDefault(b => b.Item1 == rec.query_pdb_id && b.Item2 == rec.query_chainid);
                        if (xq == null) continue;
                        query_group = cluster;
                        break;
                    }

                    foreach (var cluster in homologs_clustered)
                    {
                        var xt =
                            cluster.FirstOrDefault(b => b.Item1 == rec.target_pdb_id && b.Item2 == rec.target_chainid);
                        if (xt == null) continue;
                        target_group = cluster;
                        break;
                    }

                    var new_group = new List<Tuple<string, string>>();

                    if (query_group != null)
                    {
                        new_group.AddRange(query_group);
                        homologs_clustered.Remove(query_group);
                        query_group.Clear();
                    }
                    else
                    {
                        new_group.Add(new Tuple<string, string>(rec.query_pdb_id, rec.query_chainid));
                    }

                    if (target_group != null)
                    {
                        new_group.AddRange(target_group);
                        homologs_clustered.Remove(target_group);
                        target_group.Clear();
                    }
                    else
                    {
                        new_group.Add(new Tuple<string, string>(rec.target_pdb_id, rec.target_chainid));
                    }

                    new_group = new_group.Distinct().ToList();
                    new_group = new_group.OrderBy(a => a.Item1).ThenBy(a => a.Item2).ToList();

                    homologs_clustered.Add(new_group);
                }
            }

            var seq_list_ids = seq_list.Select(a => FindAtomicContacts.SequenceIdToPdbIdAndChainId(a.ID)).ToList();


            var wd2 = new WorkDivision(homologs_clustered.Count);
            for (var thread2 = 0; thread2 < wd2.ThreadCount; thread2++)
            {
                var lti2 = thread2;

                var task2 = Task.Run(() =>
                {
                    for (var index2 = wd2.ThreadFirstIndex[lti2]; index2 <= wd2.ThreadLastIndex[lti2]; index2++)
                    {
                        var cluster2 = homologs_clustered[index2];


                        var wd3 = new WorkDivision(cluster2.Count);

                        for (var thread3 = 0; thread3 < wd3.ThreadCount; thread3++)
                        {
                            var lti3 = thread3;
                            var cluster3 = cluster2;

                            var index4 = index2;
                            var task3 = Task.Run(() =>
                            {
                                var result = new List<string>();
                                for (var index3 = wd3.ThreadFirstIndex[lti3]; index3 <= wd3.ThreadLastIndex[lti3]; index3++)
                                {
                                    var item = cluster3[index3];
                                    ISequence s = null;
                                    for (var j = 0; j < seq_list.Count; j++)
                                    {
                                        if (seq_list_ids[j].PdbId == item.Item1 && seq_list_ids[j].ChainId == item.Item2)
                                        {
                                            s = seq_list[j];
                                            break;
                                        }
                                    }
                                    var complexChains = seq_list_ids.Count(a => a.PdbId == item.Item1);

                                    var minAlignmentScore = 1m;
                                    var maxAlignmentScore = 0m;


                                    var min_alignment_score_evo = 1m;
                                    var max_alignment_score_evo = 0m;

                                    foreach (var item2 in cluster3)
                                    {
                                        if (item == item2) continue;

                                        ISequence s2 = null;
                                        for (var j2 = 0; j2 < seq_list.Count; j2++)
                                        {
                                            if (seq_list_ids[j2].PdbId == item2.Item1 &&
                                                seq_list_ids[j2].ChainId == item2.Item2)
                                            {
                                                s2 = seq_list[j2];
                                                break;
                                            }
                                        }

                                        var alignmentScore = FindAtomicContacts.AlignedSequenceSimilarityPercentage(s,
                                            s2,
                                            FindAtomicContacts.AlignmentType.NMW);

                                        if (alignmentScore.Item1 > maxAlignmentScore)
                                            maxAlignmentScore = alignmentScore.Item1;
                                        if (alignmentScore.Item1 < minAlignmentScore)
                                            minAlignmentScore = alignmentScore.Item1;

                                        if (alignmentScore.Item2 > max_alignment_score_evo)
                                            max_alignment_score_evo = alignmentScore.Item2;
                                        if (alignmentScore.Item2 < min_alignment_score_evo)
                                            min_alignment_score_evo = alignmentScore.Item2;
                                    }

                                    result.Add(string.Join(",", new string[] { ""+(index4+1), ""+(index3+1), item.Item1, item.Item2, "" + complexChains,
                                        "" + s.Count, "" + minAlignmentScore, "" + maxAlignmentScore,
                                        "" + min_alignment_score_evo, "" + max_alignment_score_evo, s.ConvertToString()}));
                                    
                                }
                                return result;
                            });
                            wd3.TaskList.Add(task3);
                        }
                        wd3.WaitAllTasks();


                        var result2 = new List<string>();

                        result2.Add("; Cluster # " + (index2+1) + " with " + wd3.ItemsToProcess + " protein chains");
                        result2.Add(
                            "cluster index,item index,pdb id,chain id,complex chains,seq len,min clstr sid,max clstr sid,min evo clstr sid,max evo clstr sid,sequence");

                        foreach (var task in wd3.TaskList)
                        {
                            if (task.IsFaulted || task.IsCanceled) continue;
                            var tr = task as Task<List<string>>;
                            if (tr == null || tr.Result == null) continue;
                            result2.AddRange(tr.Result);
                        }

                        Console.WriteLine(Environment.NewLine + string.Join(Environment.NewLine, result2));
                    }
                });
                wd2.TaskList.Add(task2);
            }
            wd2.WaitAllTasks();
            // partners may have other interfaces, should those also be considered?
        }

        public class homolog_csv
        {
            public decimal alignment_score;
            public string alignment_type;
            public string query_chainid;
            public string query_chains;
            public string query_pdb_id;
            public string target_chainid;
            public string target_chains;
            public string target_pdb_id;

            public homolog_csv(string line)
            {
                var split = line.Split(',');

                if (split.Length != 8) return;

                query_pdb_id = split[0];
                query_chainid = split[1];
                query_chains = split[2];
                target_pdb_id = split[3];
                target_chainid = split[4];
                target_chains = split[5];
                alignment_type = split[6];
                alignment_score = decimal.Parse(split[7]);
            }
        }
    }
}