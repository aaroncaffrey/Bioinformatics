﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProteinBioinformaticsSharedLibrary;

namespace SequenceStructureOffset
{
    class SequenceStructureOffset
    {
        public static Tuple<string, string> SimpleAlignmentOffset(string sequenceA, string sequenceB)
        {
            if (String.IsNullOrEmpty(sequenceA) || String.IsNullOrEmpty(sequenceB))
            {
                return new Tuple<string, string>(sequenceA, sequenceB);
            }



            var sA = sequenceA.ToList();
            var sB = sequenceB.ToList();

            var origSaLen = sA.Count;
            var origSbLen = sB.Count;

            // pad longest with length of shortest & pad shortest with length of longest
            sA.InsertRange(0, new List<char>(new string('\0', Math.Abs(sB.Count - sA.Count))));
            sB.InsertRange(0, new List<char>(new string('\0', Math.Abs(sA.Count - sB.Count))));

            var longest = sA.Count > sB.Count ? sA : sB;
            var shortest = longest == sA ? sB : sA;

            shortest.InsertRange(0, new List<char>(new string('\0', origSaLen > origSbLen ? origSaLen : origSbLen)));

            // 0000000000000000AAAAA
            // 00000AAAAAAAAAAA

            var a = String.Join("", sA);
            var b = String.Join("", sB);

            var bestOffset = 0;
            var bestMatch = 0;
            var bestSA = "";
            var bestSB = "";

            while (shortest.Count > 1)
            {
                shortest.RemoveAt(0);

                var match = 0;

                for (var i = 0; i < shortest.Count; i++)
                {
                    if (i > longest.Count - 1) break;

                    if ((shortest[i] != '\0' && shortest[i] == longest[i]) || (shortest[i] == 'X' || longest[i] == 'X')) match++;
                }

                if (bestMatch == 0 || match >= bestMatch)
                {
                    bestMatch = match;
                    bestOffset = shortest.Count;
                    bestSA = String.Join("", sA);
                    bestSB = String.Join("", sB);

                    var trim = 0;
                    for (var j = 0; j < (bestSA.Length > bestSB.Length ? bestSB.Length : bestSA.Length); j++)
                    {
                        if (bestSA[j] == '\0' && bestSB[j] == '\0') trim++;
                        else break;
                    }
                    bestSA = bestSA.Remove(0, trim);
                    bestSB = bestSB.Remove(0, trim);
                }


            }


            return new Tuple<string, string>(bestSA, bestSB);
        }

        static void Main(string[] args)
        {
            var parameters = new string[,]
            {
                {"[pdb_or_atoms_file]", "input structure for sequence"},
                {"[fasta_file]", "input sequence for structure"},
                {"[[output_file]]", "optional output file"},
            };

            var maxParamLength = parameters.Cast<string>().Where((a, i) => i % 2 == 0).Max(a => a.Length);
            var exeFilename = Path.GetFileName(Process.GetCurrentProcess().MainModule.FileName);

            if (args.Length < 1)
            {
                Console.WriteLine(exeFilename + @" is a program to calculate offset between the sequence and structure.");
                Console.WriteLine();
                Console.WriteLine(@"Usage:");
                Console.WriteLine(FindAtomicContacts.WrapConsoleText(exeFilename + @" " + String.Join(" ", parameters.Cast<string>().Where((a, i) => i % 2 == 0)), maxParamLength + 2, 1));
                Console.WriteLine();
                Console.WriteLine(@"Example:");
                Console.WriteLine(FindAtomicContacts.WrapConsoleText(exeFilename + @" ""c:\pdb_db\atoms\atoms1a12.pdb"" ""c:\pdb_db\fasta\atoms1a12.fasta""", maxParamLength + 2, 1));
                Console.WriteLine();
                Console.WriteLine(@"Arguments:");
                for (var i = 0; i < parameters.GetLength(0); i++) Console.WriteLine(@" " + parameters[i, 0].PadLeft(maxParamLength, ' ') + " " + FindAtomicContacts.WrapConsoleText(parameters[i, 1], maxParamLength + 2, 1, false));
                Console.WriteLine();

                return;
            }

            // load arguments
            var p = 0;
            var atomsFilename = args.Length > p && args[p].Length > 0 ? args[p] : "";
            atomsFilename = atomsFilename.Replace("\"", "");
            Console.WriteLine("; " + parameters[p, 0].PadLeft(maxParamLength, ' ') + " = " + atomsFilename);

            p++;
            var inputFastaFilename = args.Length > p && args[p].Length > 0 ? args[p] : "";
            inputFastaFilename = inputFastaFilename.Replace("\"", "");
            Console.WriteLine("; " + parameters[p, 0].PadLeft(maxParamLength, ' ') + " = " + inputFastaFilename);

            p++;
            var outputDataFilename = args.Length > p && args[p].Length > 0 ? args[p] : "";
            outputDataFilename = outputDataFilename.Replace("\"", "");
            Console.WriteLine("; " + parameters[p, 0].PadLeft(maxParamLength, ' ') + " = " + outputDataFilename);

            Console.WriteLine();

            var struct_seq = ProteinBioinformaticsSharedLibrary.FindAtomicContacts.StructureToAaSequence(atomsFilename,
                false);

            
            //foreach (var s in struct_seq)
            //Console.WriteLine(s);

            //var fasta = File.ReadAllLines(inputFastaFilename);
            //foreach (var line in fasta)
            //{
            //    if (string.IsNullOrWhiteSpace(line))continue;
            //    if (line[0] == '>')
            //    {
            //        if (line.Contains())
            //    }

            //}

            /// not finished!
        }
    }
}
