﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using ProteinBioinformaticsSharedLibrary;

namespace ComplexContacts
{
    class ComplexContacts
    {
        static void Main(string[] args)
        {
            /* FindAtoms
             * FindContacts     c:\ds96ub\pdb1a12.pdb 8.0   > pdb1a12.contacts.csv
             * FindInterfaces   pdb1a12.contacts.csv        > pdb1a12.interfaces.csv
             * LoadInterfaceData pdb1a12.interfaces.csv     > pdb1a12.interfaces-data.csv
             * */

            var parameters = new string[,]
            {
                { "[pdb_or_atoms_file]", "output from the ComplexAtoms program"},
                { "[max_distance]", "maximum allowed contact distance in angstroms [i.e. 5.0 or 8.0]"},
                { "[[output_file]]", "optional output file.  when ommitted, output to console"},
            };

            var maxParamLength = parameters.Cast<string>().Where((a, i) => i % 2 == 0).Max(a => a.Length);
            var exeFilename = Path.GetFileName(System.Diagnostics.Process.GetCurrentProcess().MainModule.FileName);

            if (args.Length == 0)
            {
                Console.WriteLine(exeFilename + @" is a program to list atomic contacts for a PDB file ATOM records.");
                Console.WriteLine();
                Console.WriteLine(@"Usage:");
                Console.WriteLine(FindAtomicContacts.WrapConsoleText(exeFilename + @" " + String.Join(" ", parameters.Cast<string>().Where((a, i) => i % 2 == 0)), maxParamLength + 2, 1));
                Console.WriteLine();
                Console.WriteLine(@"Example:");
                Console.WriteLine(FindAtomicContacts.WrapConsoleText(exeFilename + @" ""c:\pdb_db\pdb1a12.pdb"" 8.0 ""c:\pdb_atoms\atoms1a12.pdb""", maxParamLength + 2, 1));
                Console.WriteLine();
                Console.WriteLine(@"Arguments:");
                for (var i = 0; i < parameters.GetLength(0); i++) Console.WriteLine(@" " + parameters[i, 0].PadLeft(maxParamLength, ' ') + " " + FindAtomicContacts.WrapConsoleText(parameters[i, 1], maxParamLength + 2, 1, false));
                Console.WriteLine();
                //return;
            }

            // load arguments
            var p = 0;
            var atomsFilename = args.Length >p && args[p].Length > 0 ? args[p] : "";
            atomsFilename = atomsFilename.Replace("\"", ""); 
            Console.WriteLine("; " + parameters[p, 0].PadLeft(maxParamLength, ' ') + " = " + atomsFilename);

            p++;
            var maxDistance = args.Length >p && args[p].Length > 0 ? Decimal.Parse(args[p]) : 0.0m;
            Console.WriteLine("; " + parameters[p, 0].PadLeft(maxParamLength, ' ') + " = " + maxDistance);

            p++;
            var outputFilename = args.Length >p && args[p].Length > 0 ? args[p] : "";
            outputFilename = outputFilename.Replace("\"", ""); 
            Console.WriteLine("; " + parameters[p, 0].PadLeft(maxParamLength, ' ') + " = " + outputFilename);

            Console.WriteLine();


            var interactions = FindAtomicContacts.FindInteractions(CancellationToken.None, maxDistance, atomsFilename, new Dictionary<string, List<string>>());

            if (!string.IsNullOrWhiteSpace(outputFilename))
            {
                FindAtomicContacts.AtomPair.SaveAtomPairList(outputFilename, interactions);
            }
            else
            {
                //Console.WriteLine("; Atom pairs with contacts: " + interactions.Count);
                foreach (var a in interactions.Select(a => a.ToString()).ToList())
                {
                    Console.WriteLine(a);
                }
            }

        }
    }
}
