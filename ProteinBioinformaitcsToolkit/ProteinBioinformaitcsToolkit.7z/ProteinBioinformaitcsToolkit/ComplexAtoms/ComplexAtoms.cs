﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProteinBioinformaticsSharedLibrary;

namespace ComplexAtoms
{
    class ComplexAtoms
    {
        static void Main(string[] args)
        {
            var parameters = new string[,]
            {
                { "[pdb_file]", "PDB ~v3.3 Protein Data Bank format file [*.pdb, *.ent]"},
                { "[[chain_ids]]", "molecule chains to output [* for all]"},
                { "[[output_file]]", "optional output file.  when ommitted, output to console"},
            };

            var maxParamLength = parameters.Cast<string>().Where((a, i) => i % 2 == 0).Max(a => a.Length);
            var exeFilename = Path.GetFileName(System.Diagnostics.Process.GetCurrentProcess().MainModule.FileName);

            if (args.Length == 0)
            {
                Console.WriteLine(exeFilename + @" is a program to extract ATOM records from a PDB file.");
                Console.WriteLine();
                Console.WriteLine(@"Usage:");
                Console.WriteLine(FindAtomicContacts.WrapConsoleText(exeFilename + @" " + String.Join(" ", parameters.Cast<string>().Where((a, i) => i % 2 == 0)), maxParamLength + 2, 1));
                Console.WriteLine();
                Console.WriteLine(@"Example:");
                Console.WriteLine(FindAtomicContacts.WrapConsoleText(exeFilename + @" ""c:\pdb_db\pdb1a12.pdb"" 8.0 ""c:\pdb_atoms\atoms1a12.pdb""", maxParamLength + 2, 1));
                Console.WriteLine();
                Console.WriteLine(@"Arguments:");
                for (var i = 0; i < parameters.GetLength(0); i++) Console.WriteLine(@" " + parameters[i, 0].PadLeft(maxParamLength, ' ') + " " + FindAtomicContacts.WrapConsoleText(parameters[i, 1], maxParamLength + 2, 1, false));
                Console.WriteLine();
                return;
            }

            // load and echo arguments
            var p = 0;            
            var pdbFilename = args.Length > p && args[p].Length > 0 ? args[p] : "";
            pdbFilename = pdbFilename.Replace("\"", "");
            Console.WriteLine("; " + parameters[0, 0].PadLeft(maxParamLength, ' ') + " = " + pdbFilename);

            p++;
            var chainIds = args.Length > p && args[p].Length > 0 ? args[p] : "";
            Console.WriteLine("; " + parameters[1, 0].PadLeft(maxParamLength, ' ') + " = " + chainIds);

            p++;
            var outputFilename = args.Length > p && args[p].Length > 0 ? args[p] : "";
            outputFilename = outputFilename.Replace("\"", "");
            Console.WriteLine("; " + parameters[2, 0].PadLeft(maxParamLength, ' ') + " = " + outputFilename);

            Console.WriteLine();

            if (string.IsNullOrWhiteSpace(pdbFilename))
            {
                return;
            }

            if (chainIds.Contains('*')) chainIds = null;

            var chainIdWhiteList = !string.IsNullOrEmpty(chainIds) ? chainIds.ToUpperInvariant().Split(new char[] { ' ', ',' },StringSplitOptions.RemoveEmptyEntries) : null;

            
            var terminatedChains = new List<string>();

            var pdbfilenameShort = Path.GetFileNameWithoutExtension(pdbFilename);

            var pdbId = pdbfilenameShort.Substring(pdbfilenameShort.Length - 4).ToUpperInvariant();

            var lines = File.ReadAllLines(pdbFilename);

            var result = new List<string>();

            foreach (var line in lines)
            {
                if (line.Length < 22) continue;

                if (line.Substring(0, 4).ToUpperInvariant() == "TER ")
                {
                    var chainId = ("" + line[21]).ToUpperInvariant();

                    terminatedChains.Add(chainId);
                }


                if (line.Substring(0, 5).ToUpperInvariant() == "ATOM ")
                {
                    var chainId = ("" + line[21]).ToUpperInvariant();

                    if (terminatedChains.Contains(chainId)) continue;

                    if (chainIdWhiteList != null && chainIdWhiteList.Length > 0 && !chainIdWhiteList.Contains(chainId)) continue;
                    
                    result.Add(line);
                }
            }

            if (!string.IsNullOrWhiteSpace(outputFilename))
            {
                Directory.CreateDirectory(Path.GetDirectoryName(outputFilename));
                File.WriteAllLines(outputFilename, result);
            }
            else
            {
                foreach (var line in result)
                {
                    Console.WriteLine(line);
                }
                Console.WriteLine();
            }
        }
    }
}
