﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace FetchPdbFile
{
    class FetchPdbFile
    {
        static void Main(string[] args)
        {
            var pdbIdList = File.ReadAllLines(@"c:\ds96ub\pdbid_list.txt");

            foreach (var pdbId in pdbIdList)
            {
                var file = "pdb" + pdbId.ToLowerInvariant() + ".ent.gz";
                var link = "ftp://ftp.wwpdb.org/pub/pdb/data/structures/all/pdb/" + file;

                var save = @"c:\ds96ub\" + file;

                WebClient webClient = new WebClient();
                webClient.DownloadFile(link, file);

                Console.WriteLine("Saved: " + file);
            }
        }
    }
}
