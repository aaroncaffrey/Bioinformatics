﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using ProteinBioinformaticsSharedLibrary;
using ProteinBioinformaticsSharedLibrary.AminoAcids;
using ProteinBioinformaticsSharedLibrary.Dssp;
using ProteinBioinformaticsSharedLibrary.ProteinDataBankRecordTypes;
using ProteinBioinformaticsSharedLibrary.Stride;

namespace ComplexInterfaces
{
    class ComplexInterfaces
    {
        static void Main(string[] args)
        {
            // TODO: 
            // 1. Add non-contact-interface ATOM records from ATOM file
            // 2. Add option to only show interfaces in criteria of interfaceX-interfaceY (because at the moment A-->B and A-->C will both show as only one interface on A)
            // 3. Load secondary structure (dssp, stride, 2nd structure meta server?)

            var parameters = new string[,]
            {
                { "[pdb_or_atoms_file]", "output from the ComplexAtoms program"},
                { "[contacts_file]", "output from the ComplexContacts program"},
                { "[dssp file]", "output from DSSP program" },
                { "[stride file]", "output from STRIDE program" },
                { "[chain_ids]", "list of chains to check [i.e. A,B,C or *]"},
                { "[max_distance]", "maximum allowed contact distance in angstroms [i.e. 5.0 or 8.0]"},
                { "[min_length]", "mininum interface length [i.e. 1]"},
                { "[[densities]]", "optional densities.  when ommitted, calculated at every 0.1"},
                { "[[output_file]]", "optional output file.  when ommitted, output to console"},
            };

            var maxParamLength = parameters.Cast<string>().Where((a, i) => i % 2 == 0).Max(a => a.Length);
            var exeFilename = Path.GetFileName(System.Diagnostics.Process.GetCurrentProcess().MainModule.FileName);


            if (args.Length < 5)
            {
                Console.WriteLine(exeFilename + @" is a program to list protein-protein interfaces for a PDB file ATOM records with PDB contacts data file from ComplexContacts.");
                Console.WriteLine();
                Console.WriteLine(@"Usage:");
                Console.WriteLine(FindAtomicContacts.WrapConsoleText(exeFilename + @" " + String.Join(" ", parameters.Cast<string>().Where((a, i) => i % 2 == 0)), maxParamLength + 2, 1));
                Console.WriteLine();
                Console.WriteLine(@"Example:");
                Console.WriteLine(FindAtomicContacts.WrapConsoleText(exeFilename + @" ""c:\pdb_db\atoms\atoms1a12.pdb"" ""c:\pdb_db\contacts\contacts1a12.pdb"" * 8.0 1 ""0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1.0"" ""c:\pdb_db\interfaces\interfaces1a12.csv""", maxParamLength + 2, 1));
                Console.WriteLine();
                Console.WriteLine(@"Arguments:");
                for (var i = 0; i < parameters.GetLength(0); i++) Console.WriteLine(@" " + parameters[i, 0].PadLeft(maxParamLength, ' ') + " " + FindAtomicContacts.WrapConsoleText(parameters[i, 1], maxParamLength + 2, 1, false));
                Console.WriteLine();
                //return;
            }

            // load arguments
            var p = 0;
            var atomsFilename = args.Length > p && args[p].Length > 0 ? args[p] : "";
            atomsFilename = atomsFilename.Replace("\"", "");
            Console.WriteLine("; " + parameters[p, 0].PadLeft(maxParamLength, ' ') + " = " + atomsFilename);

            p++;
            var contactsFilename = args.Length > p && args[p].Length > 0 ? args[p] : "";
            contactsFilename = contactsFilename.Replace("\"", "");
            Console.WriteLine("; " + parameters[p, 0].PadLeft(maxParamLength, ' ') + " = " + contactsFilename);

            p++;
            var dsspFilename = args.Length > p && args[p].Length > 0 ? args[p] : "";
            dsspFilename = dsspFilename.Replace("\"", "");
            Console.WriteLine("; " + parameters[p, 0].PadLeft(maxParamLength, ' ') + " = " + dsspFilename);

            p++;
            var strideFilename = args.Length > p && args[p].Length > 0 ? args[p] : "";
            strideFilename = strideFilename.Replace("\"", "");
            Console.WriteLine("; " + parameters[p, 0].PadLeft(maxParamLength, ' ') + " = " + strideFilename);


            p++;
            var chainIds = args.Length > p && args[p].Length > 0 ? args[p].Replace(" ", "").Replace(",", ", ") : "";
            if (string.IsNullOrWhiteSpace(chainIds) || chainIds.Contains('*')) chainIds = "*";
            Console.WriteLine("; " + parameters[p, 0].PadLeft(maxParamLength, ' ') + " = " + chainIds);

            p++;
            var maxDistance = args.Length > p && args[p].Length > 0 ? Decimal.Parse(args[p]) : 0.0m;
            Console.WriteLine("; " + parameters[p, 0].PadLeft(maxParamLength, ' ') + " = " + maxDistance);

            p++;
            var minLength = args.Length > p && args[p].Length > 0 ? args[p] : "";
            if (string.IsNullOrWhiteSpace(minLength))
            {
                minLength = "1";
            }
            Console.WriteLine("; " + parameters[p, 0].PadLeft(maxParamLength, ' ') + " = " + minLength);

            p++;
            var densities = args.Length > p && args[p].Length > 0 ? args[p] : "";
            if (string.IsNullOrWhiteSpace(densities) || densities.Contains('*'))
            {
                densities = "0.0,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1.0";
            }
            densities = densities.Replace(" ", "").Replace(",", ", ");
            Console.WriteLine("; " + parameters[p, 0].PadLeft(maxParamLength, ' ') + " = " + densities);

            p++;
            var outputFilename = args.Length > p && args[p].Length > 0 ? args[p] : "";
            outputFilename = outputFilename.Replace("\"", "");
            Console.WriteLine("; " + parameters[p, 0].PadLeft(maxParamLength, ' ') + " = " + outputFilename);

            Console.WriteLine();

            // check arguments
            var atomsFilenameShort = Path.GetFileNameWithoutExtension(atomsFilename);
            var atomsFilenamePdbId = atomsFilenameShort.Length > 4 ? atomsFilenameShort.Substring(atomsFilenameShort.Length - 4) : atomsFilenameShort;

            var contactsFilenameShort = Path.GetFileNameWithoutExtension(contactsFilename);
            var contactsFilenamePdbId = contactsFilenameShort.Length > 4 ? contactsFilenameShort.Substring(contactsFilenameShort.Length - 4) : contactsFilenameShort;

            if (atomsFilenamePdbId != contactsFilenamePdbId)
            {
                Console.WriteLine(@"; Warning: Atoms and Contacts PDB filename ends do not match [ " + atomsFilenamePdbId + " , " + contactsFilenamePdbId + " ]");
                Console.WriteLine();
            }

            var pdbId = contactsFilenamePdbId;
            var minLengthInt = int.Parse(minLength);


            var splitDensities = densities.Split(new[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries).Select(decimal.Parse).ToList();

            var proteinFileChains = FindAtomicContacts.PdbAtomicChains(atomsFilename, null, -1, -1, true);
            var interactions = FindAtomicContacts.AtomPair.LoadAtomPairList(contactsFilename);

            // list of the atoms involved in contacts (not all atoms in the pdb file)
            var allContactAtoms = new List<ATOM_Record>();
            allContactAtoms.AddRange(interactions.Select(a => a.Atom1));
            allContactAtoms.AddRange(interactions.Select(a => a.Atom2));
            allContactAtoms = allContactAtoms.Distinct().ToList();

            // list of the chains which have contacts
            var contactChains = allContactAtoms.Select(a => a.chainID.FieldValue).Distinct().OrderBy(a => a).ToList();
            if (!string.IsNullOrWhiteSpace(chainIds) && chainIds != "*")
            {
                contactChains = contactChains.Where(a => chainIds.Contains(a)).ToList();
            }
            var contactsChainToChain = new Dictionary<string, Tuple<List<ATOM_Record>, List<ATOM_Record>>>();

            // A-->B List of A residues involved, List of B resides involved
            // A-->B  A--C  A--* B-->A B-->C  C-->A C-->B
            // 
            foreach (var chainIdA in contactChains)
            {
                var id = chainIdA + "-" + "*";
                var list = interactions.Where(a => a.Atom1.chainID.FieldValue == chainIdA || a.Atom2.chainID.FieldValue == chainIdA).ToList();

                var listA = list.Where(a => a.Atom1.chainID.FieldValue == chainIdA).Select(a => a.Atom1).ToList();
                listA.AddRange(list.Where(a => a.Atom2.chainID.FieldValue == chainIdA).Select(a => a.Atom2).ToList());

                var listB = list.Where(a => a.Atom1.chainID.FieldValue != chainIdA).Select(a => a.Atom1).ToList();
                listB.AddRange(list.Where(a => a.Atom2.chainID.FieldValue != chainIdA).Select(a => a.Atom2).ToList());

                contactsChainToChain.Add(id, new Tuple<List<ATOM_Record>, List<ATOM_Record>>(listA, listB));

                foreach (var chainIdB in contactChains)
                {
                    if (chainIdA == chainIdB) continue;

                    id = chainIdA + "-" + chainIdB;

                    list = interactions.Where(a => (a.Atom1.chainID.FieldValue == chainIdA && a.Atom2.chainID.FieldValue == chainIdB)
                                                       || (a.Atom1.chainID.FieldValue == chainIdB && a.Atom2.chainID.FieldValue == chainIdA)).ToList();

                    listA = list.Where(a => a.Atom1.chainID.FieldValue == chainIdA).Select(a => a.Atom1).ToList();
                    listA.AddRange(list.Where(a => a.Atom2.chainID.FieldValue == chainIdA).Select(a => a.Atom2).ToList());

                    listB = list.Where(a => a.Atom1.chainID.FieldValue == chainIdB).Select(a => a.Atom1).ToList();
                    listB.AddRange(list.Where(a => a.Atom2.chainID.FieldValue == chainIdB).Select(a => a.Atom2).ToList());

                    contactsChainToChain.Add(id, new Tuple<List<ATOM_Record>, List<ATOM_Record>>(listA, listB));

                }
            }

            // make distance matrices
            //var dms = new Dictionary<string, decimal[,]>();
            var dms = new Dictionary<string, List<Tuple<ATOM_Record, ATOM_Record, decimal>>>();

            foreach (var id in contactsChainToChain)
            {
                var chainAtoms = id.Value.Item1;//contactsChainToChain[id.Key].Item1;

                var dm = new List<Tuple<ATOM_Record, ATOM_Record, decimal>>();


                for (var x = 0; x < chainAtoms.Count; x++)
                {
                    for (var y = 0; y < chainAtoms.Count; y++)
                    {
                        //if (i == j /*|| j > i*/) continue;

                        var atom1 = chainAtoms[x];
                        var atom2 = chainAtoms[y];

                        if (!dm.Any(a => a.Item1 == atom1 && a.Item2 == atom2) &&
                            !dm.Any(a => a.Item1 == atom2 && a.Item2 == atom1))
                        {
                            dm.Add(new Tuple<ATOM_Record, ATOM_Record, decimal>(atom1, atom2,
                                Math.Abs(int.Parse(atom1.resSeq.FieldValue) - int.Parse(atom2.resSeq.FieldValue))));

                            //dm = dm.OrderBy(a => a.Item3).ToList();
                        }
                    }
                }

                dm = dm.OrderBy(a => a.Item3).ThenBy(a => int.Parse(a.Item1.resSeq.FieldValue)).ThenBy(a => int.Parse(a.Item2.resSeq.FieldValue)).ToList();

                dms.Add(id.Key, dm);
            }


            // cluster
            var chainClusters = new Dictionary<Tuple<string, decimal>, List<List<ATOM_Record>>>();

            foreach (var id in contactsChainToChain)
            {
                var chainAtoms = id.Value.Item1;// chainDividedAtoms[id];

                var dm = dms[id.Key];



                //for (var density = 0.1m; density <= 1.0m; density += 0.1m)
                foreach (var minDensity in splitDensities)
                {
                    var clusters = new List<List<ATOM_Record>>();
                    

                    var finished = false;
                    while (!finished)
                    {
                        finished = true;
                        foreach (var t in dm)
                        {
                            var atom1 = t.Item1;
                            var atom2 = t.Item2;
                            var distance = t.Item3;

                            var atom1group = clusters.FirstOrDefault(a => a.Contains(atom1));
                            var atom2group = clusters.FirstOrDefault(a => a.Contains(atom2));

                            if (atom1group != null && atom2group != null && atom1group == atom2group) continue;

                            var newgroup = new List<ATOM_Record>();

                            if (atom1group != null) newgroup.AddRange(atom1group);
                            else newgroup.Add(atom1);

                            if (atom2group != null) newgroup.AddRange(atom2group);
                            else newgroup.Add(atom2);

                            newgroup = newgroup.Distinct().ToList();

                            var min = newgroup.Min(a => int.Parse(a.resSeq.FieldValue));
                            var max = newgroup.Max(a => int.Parse(a.resSeq.FieldValue));
                            var len = (max - min) + 1;
                            var ifdensity = (decimal)newgroup.Count / (decimal)len;

                            if (ifdensity >= minDensity)
                            {
                                if (atom1group != null) clusters.Remove(atom1group);
                                if (atom2group != null) clusters.Remove(atom2group);
                                clusters.Add(newgroup);
                                finished = false;
                            }
                        }
                    }
                    clusters = clusters.OrderBy(a => a.Min(b => int.Parse(b.resSeq.FieldValue))).ThenBy(a => a.Max(b => int.Parse(b.resSeq.FieldValue))).ToList();
                    chainClusters.Add(new Tuple<string, decimal>(id.Key, minDensity), clusters);
                }
            }

            var chainIndexMap = new string[proteinFileChains.ChainList.Count];
            for (var i = 0; i < proteinFileChains.ChainList.Count; i++) chainIndexMap[i] = proteinFileChains.ChainList[i].AtomList.First().chainID.FieldValue;

            var lines = new List<String>();
            lines.Add("; " + String.Join(",", new List<string>() { "if-uid", "if-pdbid", "if-chn-src", "if-chn-dest", "if-index", "if-start", "if-end", "if-len", "if-no-contact", "if-density", "if-min-density", "if-dssp", "if-stride", "if-aa-contact", "if-aa-no-contact", "if-aa-all" }));

            var dssp = File.Exists(dsspFilename) ? DsspFormatFile.LoadDsspFile(dsspFilename) : new List<DsspRecord>();
            var stride = File.Exists(strideFilename) ? StrideFile.Load(strideFilename).Where(a => a is StrideFile.Stride_DetailedSecondaryStructureAssignments).ToList() : new List<StrideFile.Stride_Record>();

            foreach (var id in contactsChainToChain)
            {
                //for (var density = 0.1m; density <= 1.0m; density += 0.1m)

                foreach (var minDensity in splitDensities)
                {
                    var chainChainIndex = 0;
                    var clusters = chainClusters[new Tuple<string, decimal>(id.Key, minDensity)];
                    //lines.Add("; chain " + id.Key + " at density " + minDensity);
                    //lines.Add("; " + String.Join(",", new List<string>() { "if-uid", "if-pdbid", "if-chn-src", "if-chn-dest", "if-start", "if-end", "if-len", "if-no-contact", "if-density", "if-min-density", "if-dssp", "if-stride", "if-aa-contact", "if-aa-no-contact", "if-aa-all" }));

                    foreach (var cluster in clusters)

                    {
                        chainChainIndex++;
                        var min = cluster.Min(a => int.Parse(a.resSeq.FieldValue));
                        var max = cluster.Max(a => int.Parse(a.resSeq.FieldValue));
                        var len = (max - min) + 1;

                        if (len < minLengthInt) continue;

                        var ifdensity = (decimal)cluster.Count / (decimal)len;

                        var ifaaContacts = new char[len];
                        var ifaaNonContacts = new char[len];
                        var ifaaAll = new char[len];
                        var ifDssp = new char[len];
                        var ifStride = new char[len];
                        //var ifDssp = ProteinBioinformaticsSharedLibrary.Dssp.DsspStructureSequence.LoadDsspStructureSequence(atomsFilename,)

                        for (var i = 0; i < ifaaContacts.Length; i++) ifaaContacts[i] = '_';
                        for (var i = 0; i < ifaaContacts.Length; i++) ifaaNonContacts[i] = '_';
                        for (var i = 0; i < ifaaContacts.Length; i++) ifaaAll[i] = '_';
                        for (var i = 0; i < ifaaContacts.Length; i++) ifDssp[i] = '_';
                        for (var i = 0; i < ifaaContacts.Length; i++) ifStride[i] = '_';


                        var atomsChainIndex = Array.IndexOf(chainIndexMap, id.Key.Substring(0, id.Key.IndexOf("-")));


                        foreach (var atom in proteinFileChains.ChainList[atomsChainIndex].AtomList)
                        {
                            var resId = int.Parse(atom.resSeq.FieldValue);
                            if (resId >= min && resId <= max)
                            {
                                var resDssp = dssp.FirstOrDefault(a => !string.IsNullOrWhiteSpace(a.FieldPdbResidueSequenceIndex.FieldValue) && a.FieldPdbResidueSequenceIndex.FieldValue.All(char.IsDigit) && int.Parse(a.FieldPdbResidueSequenceIndex.FieldValue) == resId);
                                if (resDssp != null) ifDssp[max - resId] = resDssp.FieldSecondaryStructure.FieldValue.DefaultIfEmpty('_').First();

                                var resStride = stride.FirstOrDefault(a => !string.IsNullOrWhiteSpace(((StrideFile.Stride_DetailedSecondaryStructureAssignments)a).PdbResidueNumber) && ((StrideFile.Stride_DetailedSecondaryStructureAssignments)a).PdbResidueNumber.All(char.IsDigit) && int.Parse(((StrideFile.Stride_DetailedSecondaryStructureAssignments)a).PdbResidueNumber) == resId);
                                if (resStride != null) ifStride[max - resId] = ((StrideFile.Stride_DetailedSecondaryStructureAssignments)resStride).OneLetterSecondaryStructureCode.DefaultIfEmpty('_').First();

                                ifaaAll[max - resId] = AminoAcidConversions.AminoAcidNumberToCode1L(AminoAcidConversions.AminoAcidNameToNumber(atom.resName.FieldValue)).First();
                                if (!cluster.Any(atom.Equals))
                                {
                                    ifaaNonContacts[max - resId] = AminoAcidConversions.AminoAcidNumberToCode1L(AminoAcidConversions.AminoAcidNameToNumber(atom.resName.FieldValue)).First();
                                }
                            }

                        }

                        foreach (var atom in cluster)
                        {
                            var seqId = int.Parse(atom.resSeq.FieldValue);
                            var index = max - seqId;
                            ifaaContacts[index] = AminoAcidConversions.AminoAcidNumberToCode1L(AminoAcidConversions.AminoAcidNameToNumber(atom.resName.FieldValue)).First();
                        }

                        lines.Add(String.Join(",",
                            new List<string>()
                            {
                                String.Join("-", new List<string>() {  "IF", pdbId, id.Key, min.ToString().PadLeft(5, '0'), max.ToString().PadLeft(5, '0') }) +
                                "-" + minDensity,
                                pdbId,
                                id.Key.Substring(0,1),
                                id.Key.Substring(2,1),
                                chainChainIndex.ToString(),
                                min.ToString().PadLeft(5, '0'),
                                max.ToString().PadLeft(5, '0'),
                                len.ToString(),
                                ifaaContacts.Count(a => a == '_').ToString(),
                                ifdensity.ToString(),
                                minDensity.ToString(),
                                String.Join("", ifDssp),
                                String.Join("", ifStride),
                                String.Join("", ifaaContacts),
                                String.Join("", ifaaNonContacts),
                                String.Join("", ifaaAll),
                            }));
                    }
                    //lines.Add("");
                }
            }

            lines = lines.OrderBy(a => a).ToList();

            if (!string.IsNullOrWhiteSpace(outputFilename))
            {
                Directory.CreateDirectory(Path.GetDirectoryName(outputFilename));
                File.WriteAllLines(outputFilename, lines);
            }
            else
            {
                foreach (var line in lines)
                {
                    Console.WriteLine(line);
                }
            }
        }
    }

}