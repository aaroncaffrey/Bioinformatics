﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using ProteinBioinformaticsSharedLibrary;

namespace MutateSequence
{
    class MutateSequence
    {

        static void Main(string[] args)
        {
            //var s1 =
            //    @"XXXXXXXXXXXXXXXXXXXXKKVKVSHRSHSTEPGLVLTLGQGDVGQLGLGENVMERKKPALVSIPEDVVQAEAGGMHTVCLSKSGQVYSFGCNDEGALGRDTSVEGSEMVPGKVELQEKVVQVSAGDSHTAALTDDGRVFLWGSFRDNNGVIGLLEPMKKSMVPVQVQLDVPVVKVASGNDHLVMLTADGDLYTLGCGEQGQLGRVPELFANRGGRQGLERLLVPKCVMLKSRGSRGHVRFQDAFCGAYFTFAISHEGHVYGFGLSNYHQLGTPGTESCFIPQNLTSFKNSTKSWVGFSGGQHHTVCMDSEGKAYSLGRAEYGRLGLGEGAEEKSIPTLISRLPAVSSVACGASVGYAVTKDGRVFAWGMGTNYQLGTGQDEDAWSPVEMMGKQLENRVVLSVSSGGQHTVLLVKDKEQS";

            //var s2 = @"RRSPPADAIPKSKKVKVSHRSHSTEPGLVLTLGQGDVGQLGLGENVMERKKPALVSIPEDVVQAEAGGMHTVCLSKSGQVYSFGCNDEGALGRDTSVEGSEMVPGKVELQEKVVQVSAGDSHTAALTDDGRVFLWGSFRDNNGVIGLLEPMKKSMVPVQVQLDVPVVKVASGNDHLVMLTADGDLYTLGCGEQGQLGRVPELFANRGGRQGLERLLVPKCVMLKSRGSRGHVRFQDAFCGAYFTFAISHEGHVYGFGLSNYHQLGTPGTESCFIPQNLTSFKNSTKSWVGFSGGQHHTVCMDSEGKAYSLGRAEYGRLGLGEGAEEKSIPTLISRLPAVSSVACGASVGYAVTKDGRVFAWGMGTNYQLGTGQDEDAWSPVEMMGKQLENRVVLSVSSGGQHTVLLVKDKEQS";

            //var x = SimpleAlignmentOffset(s1,s2);

            //Console.WriteLine();
            //Console.WriteLine(x.Item1);
            //Console.WriteLine(x.Item2);
            //Console.WriteLine();
            //Console.ReadLine();
            //return;

            // MutateSequence example.fasta start end mutation original (will find closest to start/end in case of sequence/structure index misalignment)

            var parameters = new string[,]
            {
                { "[input_fasta_file]", "fasta file with sequence to mutate" },
                { "[chain_ids]", "chain ids to mutate" },
                { "[start_positions]", "mutation start position (one based)" },
                { "[end_positions]", "mutation end position (one based)" },
                { "[offsets]", "mutation end position (one based)" },
                { "[mutation_sequence]", "new amino acids to overwrite with"},
                { "[[output_fasta_file]]", "optional output fasta file.  when ommitted, output to console"},
            };

            var maxParamLength = parameters.Cast<string>().Where((a, i) => i % 2 == 0).Max(a => a.Length);
            var exeFilename = Path.GetFileName(System.Diagnostics.Process.GetCurrentProcess().MainModule.FileName);

            if (args.Length < 5)
            {
                Console.WriteLine(exeFilename + @" is a program to mutate (substitute) a subsequence of a protein amino acid sequence within a fasta file.");
                Console.WriteLine();
                Console.WriteLine(@"Usage:");
                Console.WriteLine(FindAtomicContacts.WrapConsoleText(exeFilename + @" " + String.Join(" ", parameters.Cast<string>().Where((a, i) => i % 2 == 0)), maxParamLength + 2, 1));
                Console.WriteLine();
                Console.WriteLine(@"Example:");
                Console.WriteLine(FindAtomicContacts.WrapConsoleText(exeFilename + @" ""c:\pdb_db\fasta\fasta_pdb1a12.pdb.fasta"" A,B,C 10,76,100 15,77,102 GBVBGA,AA,GHG ""c:\pdb_db\fasta_mutated\mutated_pdb1a12.pdb.fasta""", maxParamLength + 2, 1));
                Console.WriteLine();
                Console.WriteLine(@"Arguments:");
                for (var i = 0; i < parameters.GetLength(0); i++) Console.WriteLine(@" " + parameters[i, 0].PadLeft(maxParamLength, ' ') + " " + FindAtomicContacts.WrapConsoleText(parameters[i, 1], maxParamLength + 2, 1, false));
                Console.WriteLine();
                return;
            }

            var p = 0;
            var input_fasta_file = args.Length > p && args[p].Length > 0 ? args[p] : "";
            input_fasta_file = input_fasta_file.Replace("\"", "");
            Console.WriteLine("; " + parameters[p, 0].PadLeft(maxParamLength, ' ') + " = " + input_fasta_file);

            p++;
            var chain_ids = args.Length > p && args[p].Length > 0 ? args[p] : "";
            chain_ids = chain_ids.Replace("\"", "");
            Console.WriteLine("; " + parameters[p, 0].PadLeft(maxParamLength, ' ') + " = " + chain_ids);
            var chain_ids_split = chain_ids.ToUpperInvariant().Split(',');

            p++;
            var start_position = args.Length > p && args[p].Length > 0 ? args[p] : "";
            start_position = start_position.Replace("\"", "");
            Console.WriteLine("; " + parameters[p, 0].PadLeft(maxParamLength, ' ') + " = " + start_position);
            var start_position_split = start_position.Split(',');

            p++;
            var end_position = args.Length > p && args[p].Length > 0 ? args[p] : "";
            end_position = end_position.Replace("\"", "");
            Console.WriteLine("; " + parameters[p, 0].PadLeft(maxParamLength, ' ') + " = " + end_position);
            var end_position_split = end_position.Split(',');

            p++;
            var offset_position = args.Length > p && args[p].Length > 0 ? args[p] : "";
            offset_position = offset_position.Replace("\"", "");
            Console.WriteLine("; " + parameters[p, 0].PadLeft(maxParamLength, ' ') + " = " + offset_position);
            var offset_position_split = offset_position.Split(',');

            p++;
            var mutation_sequence = args.Length > p && args[p].Length > 0 ? args[p] : "";
            mutation_sequence = mutation_sequence.Replace("\"", "");
            Console.WriteLine("; " + parameters[p, 0].PadLeft(maxParamLength, ' ') + " = " + mutation_sequence);
            var mutation_sequence_split = mutation_sequence.Split(',');

            p++;
            var output_fasta_file = args.Length > p && args[p].Length > 0 ? args[p] : "";
            output_fasta_file = output_fasta_file.Replace("\"", "");
            Console.WriteLine("; " + parameters[p, 0].PadLeft(maxParamLength, ' ') + " = " + output_fasta_file);

            Console.WriteLine();

            var fasta = File.ReadAllLines(input_fasta_file);
            var chain_id = "";
            var chain_aa = "";

            var headerDict = new Dictionary<string, string>();
            var fastaDict = new Dictionary<string, string>();

            foreach (var line in fasta)
            {
                if (string.IsNullOrWhiteSpace(line)) continue;

                if (line[0] == '>')
                {
                    var split_chars = new char[] { '>', ':', '|', ',', ';', '\t', ' ', };

                    var header_data = line.Split(split_chars.Where(a => !chain_ids_split.Any(b => b.Contains(a))).ToArray());
                    chain_id = header_data.FirstOrDefault(a => chain_ids_split.Contains(a.ToUpperInvariant()));
                    if (chain_id == default(string))
                    {
                        chain_id = line;
                    }

                    headerDict.Add(chain_id, line);
                    fastaDict.Add(chain_id, "");
                }
                else
                {
                    fastaDict[chain_id] += line.Trim();
                }

            }

            for (int index = 0; index < chain_ids_split.Length; index++)
            {
                var id = chain_ids_split[index];

                if (!headerDict.ContainsKey(id))
                {
                    Console.WriteLine("Warning: Chain '" + id + "' not found in sequence file.");
                    continue;
                }

                var offset = int.Parse(offset_position_split[index]);
                var start = (int.Parse(start_position_split[index]) - 1) + offset; // one based to zero based
                var end = (int.Parse(end_position_split[index]) - 1) + offset;
                var len = (end - start) + 1;

                var aa = mutation_sequence_split[index].ToCharArray();
                var fastaSeq = fastaDict[id].ToCharArray();

                var pos = 0;
                for (var i = start; i <= end; i++)
                {
                    fastaSeq[i] = aa[pos];
                    pos++;
                    if (pos > aa.Length - 1) pos = 0;
                }
                fastaDict[id] = new string(fastaSeq);
            }

            var result = new List<string>();
            foreach (var id in headerDict)
            {
                result.Add(id.Value);
                var s = fastaDict[id.Key];
                while (s.Length > 80)
                {
                    result.Add(s.Substring(0, 80));
                    s = s.Remove(0, 80);
                }
                if (s.Length > 0) result.Add(s);

                //result.Add(fastaDict[id.Key]);
            }

            if (!string.IsNullOrWhiteSpace(output_fasta_file))
            {
                Directory.CreateDirectory(Path.GetDirectoryName(output_fasta_file));
                File.WriteAllLines(output_fasta_file, result);
            }
            else
            {
                foreach (var line in result)
                {
                    Console.WriteLine(line);
                }
                Console.WriteLine();
            }
        }
    }
}
